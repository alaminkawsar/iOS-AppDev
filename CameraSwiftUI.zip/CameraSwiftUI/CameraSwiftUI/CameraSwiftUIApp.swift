//
//  CameraSwiftUIApp.swift
//  CameraSwiftUI
//
//  Created by Khayrul on 2/7/22.
//

import SwiftUI

@main
struct CameraSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
