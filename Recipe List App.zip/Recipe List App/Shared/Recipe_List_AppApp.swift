//
//  Recipe_List_AppApp.swift
//  Shared
//
//  Created by Guest User on 1/27/22.
//

import SwiftUI

@main
struct Recipe_List_AppApp: App {
    var body: some Scene {
        WindowGroup {
            RecipeListView()
        }
    }
}
