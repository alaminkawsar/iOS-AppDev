//
//  LoginPageApp.swift
//  LoginPage
//
//  Created by Guest User on 1/17/22.
//

import SwiftUI

@main
struct LoginPageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
