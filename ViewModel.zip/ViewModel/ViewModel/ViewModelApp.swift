//
//  ViewModelApp.swift
//  ViewModel
//
//  Created by Guest User on 1/24/22.
//

import SwiftUI

@main
struct ViewModelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
