//
//  ContentView.swift
//  ViewModel
//
//  Created by Guest User on 1/24/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            DataModel()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
